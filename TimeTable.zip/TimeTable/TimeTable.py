from datetime import datetime
import pyttsx3

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voices',voices[2].id)

def Speak(audio):
    '''
    Creates an engine that uses the male voice from Microsoft's speech API.
    '''
    print(f'\033[1;3mJarvis\033[0m: {audio}')
    engine.say(audio)
    engine.runAndWait()

FiveTo6 = '''
In This Time , 
You Have To Get Up & Listen to something Positive. Consider an early morning workout too/
5:00 Am To 6:00 Am 
Thanks.
'''

SixTo9 = '''
In This Time , 
You Have To Study .
6:00 Am To 9:00 Am .
Thanks .
'''

NineTo12 = '''
In This Time ,
You Have A Write a Blog.
9:00 Am To 12:00 Pm .
Thanks .
'''
OneToTwo = '''
In This Time,
you have to Eat Lunch
1:00pm to 2:00pm.
Thanks
'''

TwoTo15 = '''
In This Time ,
You Have To Gain Some Knowledge From The Internet OR read a Book.
2:00 Pm To 3:00 Pm .
Thanks .
'''

FifteenTo21 = '''
In This Time ,
You Have To Code .
3:00 Pm To 9:00 Pm .
Thanks .
'''

TwentyOneTo22 = '''
In This Time ,
You Have To have Dinner.
9:00 Pm To 10:00 Pm .
Thanks .
'''

def Time():

    hour = int(datetime.now().strftime("%H"))

    if hour>=5 and hour<6:
        Speak(FiveTo6)
        return FiveTo6
        
    elif hour>=6 and hour<9:
        Speak(SixTo9)
        return SixTo9

    elif hour>=9 and hour<12:
        Speak(NineTo12)
        return NineTo12

    elif hour>=1 and hour<2:
        Speak(OneToTwo)
        return OneToTwo

    elif hour>=12 and hour<15:
        Speak(TwoTo15)
        return TwoTo15

    elif hour>=15 and hour<21:
        Speak(FifteenTo21)
        return FifteenTo21

    elif hour>=21 and hour<22:
        Speak(TwentyOneTo22)
        return TwentyOneTo22
        
    else:
        Speak("In This Time , You Have To Sleep ")

        return '''In This Time , You Have To Sleep .'''
